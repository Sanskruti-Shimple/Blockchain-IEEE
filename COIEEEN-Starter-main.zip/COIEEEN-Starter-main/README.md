# COIEEEN-Starter
Starter files for the IEEE SB VIT, Pune's COIEEEN blockchain project. Clone this repo to get started with the COIEEEN project. Happy coding! 👨‍💻 👩‍💻


## Tools & Technologies 👨‍💻
![](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)&nbsp;&nbsp;![](https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white)&nbsp;&nbsp;![](https://img.shields.io/badge/HTML-239120?style=for-the-badge&logo=html5&logoColor=white)&nbsp;&nbsp;![](https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white)
